#include<iostream>
#include<math.h>
using namespace std;
class Point{
	public:
	int x, y;
	public:
	Point(){
	}
	friend istream &operator>>(istream &a, Point &p);
	friend ostream &operator<<(ostream &a, Point p);
	double distance();
	bool operator>(Point p2);
};
Point p0;
   double Point::distance(){
		return sqrt((x-p0.x)*(x-p0.x)+(y-p0.y)*(y-p0.y));
	}
	bool Point::operator>(Point p2){
		if((p2.x - p0.x)*(y - p0.y) > (x - p0.x)*(p2.y - p0.y))
		    return true;
		else if(((p2.x - p0.x)*(y - p0.y) == (x - p0.x)*(p2.y - p0.y)) && distance() > p2.distance())
			return true;
		else
			return false;
	}

istream &operator>>(istream &a, Point &p){
	a>>p.x>>p.y;
	return a;
}

ostream &operator<<(ostream &a, Point p){
	a<<"("<<p.x<<", "<<p.y<<")";
	return a;
}
void read(Point a[], int n){
	cout<<"Enter " << n << " points\n";
	for(int i=0; i<n; i++)
		cin >> a[i];
}

void print(Point a[], int n){
	cout<<"\nList of points is: [";
	for(int i=0; i<n; i++)
		cout << a[i] << ", ";
	cout<<"\b\b]";
}
class Node{
	public:
	Point data;
	Node *LLink, *RLink;
};
class DCLL{
	Node *first;
	public:
	DCLL(){first = NULL;}
	void create(Point a[], int n);
	void display();
	Node *getFirst(){ return first;}
	void del(Node *n);
};

void DCLL::del(Node *d){
	if(first == NULL) return;
	if(first->RLink != first){
		Node *prev, *next;
		prev = d->LLink; next = d->RLink;
		prev->RLink = next; next->LLink = prev;
		if (first == d){
			first = next;
		}
	}
	else{
		first = NULL;
	}
	
	d->LLink = d->RLink = NULL;
	delete(d);
}
void DCLL::create(Point a[], int n){
	Node *cur;
	for(int i=1; i<=n; i++){
		if(i==1){
			first = cur = new Node();
		}else{
			Node *prev = cur;
			cur->RLink = new Node();
			cur = cur->RLink;
			cur->LLink = prev;
		}
		cur->data = a[i-1];
	}
	cur->RLink = first;
	first->LLink = cur;
}

void DCLL::display(){
	cout<<"[";
	Node *cur = first;
	while(cur->RLink != first)
	{
		cout<<cur->data<<", ";
		cur = cur->RLink;
	}
	cout<<cur->data<<"]\n";
}
void bubbleSort(Point a[], int n){
	for(int i=1; i<n; i++){
		bool isSorted = true;
		for(int j=0; j<=n-i-1; j++){
			if(a[j] > a[j+1]){
				Point x = a[j]; a[j] = a[j+1]; a[j+1] = x;
				isSorted = false;
			}
		}
		if(isSorted == true)
		   break;
	}
}
Point getP0(Point a[], int n){
	Point p0 = a[0];
	for(int i=1; i<n; i++)
		if(a[i].y < p0.y || (a[i].y == p0.y && a[i].x < p0.x))
		   p0 = a[i];
	return p0;
}
bool isAngleLE180(Point p1, Point p2, Point p3){
	if((p2.x - p1.x)*(p3.y-p2.y) <= (p3.x - p2.x)*(p2.y - p1.y))
		return true;
	else
		return false;
}
void getConvexHull(Point a[], int n){
	DCLL lst;
	lst.create(a, n);
	Node *x = lst.getFirst(), *xr, *xrr, *x0;
	x0 = x; xr=x->RLink; xrr=xr->RLink;
	while(xrr != x0 || xr != xrr){
		xrr=xr->RLink;
		if(isAngleLE180(x->data, xr->data, xrr->data) == true){
			lst.del(xr); xr = x; x = x->LLink;
		}else{
			x = xr; xr = xrr;
		}
	}
	cout<<"\nVertices of convex hull: ";
	lst.display();
}
int main(){
	cout<<"How many points? ";
	int n;
	cin >> n;
	Point *a = new Point[n];
	read(a, n);
	print(a, n);
	p0 = getP0(a, n);
	bubbleSort(a, n);
	print(a, n);
	getConvexHull(a, n);
	return 0;
}
