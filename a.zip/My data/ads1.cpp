#include <iostream>
using namespace std;

class Array
{
	int *arr;
	int maxsize;
	int size;

public:
	Array(int n)
	{
		arr = new int[n];
		maxsize = n;
		size = 0;
	}

	int getsize()
	{
		return size;
	}

	int getmaxsize()
	{
		return maxsize;
	}

	void insert(int x, int index)
	{
		if (size == maxsize)
		{
			cout << "Array is full. Insertion operation failed." << endl;
			return;
		}
		if (index < 0 || index > size)
		{
			cout << "Invalid index. Insertion operation failed." << endl;
			return;
		}

		for (int i = size - 1; i >= index; i--)
		{
			arr[i + 1] = arr[i];
		}
		arr[index] = x;
		size++;
	}

	int del(int index)
	{
		int movements = 0;
		if (index >= size || index < 0)
		{
			cout << "Invalid index." << endl;
			return 0;
		}
		for (int i = index; i < size - 1; i++)
		{
			arr[i] = arr[i + 1];
			movements++;
		}
		size = size - 1;
		return movements;
	}

	void display()
	{
		cout << "[";
		for (int i = 0; i < size; i++)
		{
			cout << arr[i] << ", ";
		}
		cout << "]" << endl;
	}
};

// Store all even numbers after all odd integers
void storeEvenOdd(Array &a)
{
	int oddSize = 0, x;
	cout << "Input " << a.getmaxsize() << " elements" << endl;
	for (int i = 0; i < a.getmaxsize(); i++)
	{
		cin >> x;
		if (x % 2 != 0)
		{
			a.insert(x, oddSize);
			oddSize++;
		}
		else
		{
			a.insert(x, a.getsize());
		}
	}
}

void storeSeries(Array &arr, int n)
{
	int index = 0;
	for (int i = 1; i <= n; i++)
	{
		arr.insert(i, index++);
		if (i % 2 == 0)
		{
			arr.insert(i, index++);
		}
	}
}

int mainOddEven()
{
	int size, idx;
	cout << "Input the size of array: ";
	cin >> size;
	Array arr(size);
	storeEvenOdd(arr);

	cout << "Array:" << endl;
	arr.display();

	cout << "Input index to remove element: ";
	cin >> idx;
	arr.del(idx);
	arr.display();
}

int mainSeries()
{
	int n, idx, size;

	cout << "Input even number n: ";
	cin >> n;
	if (n % 2 != 0)
	{
		n--;
	}
	size = 3 * n / 2;
	Array arr(size), arr2(size);
	storeSeries(arr, n);
	storeSeries(arr2, n);

	cout << "Array:" << endl;
	arr.display();

	int movements = 0;
	cout << "Removing duplicates in minimum movements:\n";
	for (int i = arr.getsize() - 1; i >= 0; i -= 3)
	{
		movements += arr.del(i);
	}
	arr.display();
	cout << "No. of movements= " << movements << endl;

	arr2.display();
	movements = 0;
	cout << "Removing duplicates in maximum movements:\n";

	// TODO: last element is not being removed
	for (int i = 1; i < arr2.getsize(); i += 2)
	{
		movements += arr2.del(i);
	}
	arr2.display();
	cout << "No. of movements= " << movements;
}

main()
{
	// mainOddEven();
	mainSeries();
}