//Two LUTM Multiplication

#include <iostream>
using namespace std;
int**multiplyLUTM(int **a,int **b, int n){
	int **c=new int*[n];
	int i, j,k;
	for(i=0;i<n;i++)
		c[i]=new int[n];
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			c[i][j]=0;
			for(k=0;i<(n-1)-(i>j?i:j);i++){
				c[i][j]=c[i][j]+(a[i][k]*b[k][j]);
			}	
		}		
	}	
	return c;
}
void read(int **a,int n){
	int i,j;
	for(i=0;i<n;i++)
		for(j=0;j<n;j++){
			cout<<"A["<<i<<"]["<<j<<"] : "<<endl;
			cin>>a[i][j];
		}
}
void print(int **a,int n){
	int i,j;
	for(i=0;i<n;i++){
		cout<<endl;
		for(j=0;j<n;j++)
			cout<<a[i][j]<<" ";
	}	
}
int main(){
	int i;
//	int a[][3]={{1,2,3},{4,5,0},{6,0,0}};
//	int b[][3]={{6,5,4},{3,2,0},{1,0,0}};
	
	int **a=new int*[3];
	int **b=new int*[3];
	for(i=0;i<3;i++)
	{
		a[i]=new int[3];
		b[i]=new int[3];
	}
	
	read(a,3);
	read(b,3);
	
	print(a,3);
	print(b,3);
	
	
	print(multiplyLUTM(a,b,3),3);
}
