#include<iostream>
using namespace std;
void readLUTM(int **a, int n){
	cout<<"Enter the non-null element of Left Upper Triangular Matrix\n";
	for(int i=0; i<n; i++)
		for(int j=0; j<n-i; j++)
			cin>>a[i][j];
}
void printLUTM(int **a, int n){
	cout<<"The Left Upper Triangular Matrix\n";
	for(int i=0; i<n; i++){
		for(int j=0; j<n; j++)
		   if(i+j <= n-1)
			   cout<<a[i][j]<<"\t";
			else
				cout << "0\t";
	    cout<<"\n";
	}
}
void printSM(int **a, int n){
	cout<<"The Square Matrix\n";
	for(int i=0; i<n; i++){
		for(int j=0; j<n; j++)
			   cout<<a[i][j]<<"\t";
	    cout<<"\n";
	}
}
int max(int a, int b){
	return a>b?a:b;
}
int **mulLUTMAndLUTM(int **a, int **b, int n){
	int *c= new int[n];
	for(int i=0; i<n; i++)
		c[i] = new int[n];
	for(int i=0; i<n; i++){
		for(int j=0; j<n; j++){
			c[i][j]=0;
			for(int k=0; k<=n-1-max(i, j); k++)
				c[i][j] += a[i][k]*b[k][j];
		}
	}
	return c;
}

int main()
{
	int n;
	cout<<"\nEnter n ";
	cin>>n;
	int *a= new int[n];
	for(int i=0; i<n; i++)
		a[i] = new int[n-i];
	int *b= new int[n];
	for(int i=0; i<n; i++)
		b[i] = new int[n-i];
	readLUTM(a, n);
	readLUTM(b, n);
	printLUTM(a, n); 
	printLUTM(b, n);
	int **c = mulLUTMAndLUTM(a, b, n);
	printSM(c, n);
	return 0;
}
