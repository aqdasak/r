#include<iostream>
using namespace std;
void read(int *a, int n){
  cout<<"Enter the non-null element of Upper Triangular Matrix in Column major order\n";
  for(int i=0; i<n*(n+1)/2; i++)
    cin>>a[i];
}
void print(int *a, int n){
  cout<<"The Matrix\n";
  for(int i=0; i<n; i++){
    for(int j=0; j<n; j++)
      if(i<=j)
        cout<<a[(j*(j+1)/2)+i]<<"\t";
      else
        cout << "0\t";
    cout<<"\n";
  }
}
int main()
{
  int n;
  cout<<"\nEnter n ";
  cin>>n;
  int *a= new int[n*(n+1)/2];
  read(a, n);
  print(a, n);
  return 0;
}