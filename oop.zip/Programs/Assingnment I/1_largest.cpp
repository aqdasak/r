#include <iostream>
using namespace std;

class Largest
{

    int a, b, c;

public:
    Largest(int a, int b, int c)
    {
        this->a = a;
        this->b = b;
        this->c = c;
    }

    int getLargest()
    {
        int mx = a > b ? a : b;
        mx = mx > c ? mx : c;
        return mx;
    }
};

int main()
{
    int a, b, c;
    cout << "Enter three numbers" << endl;
    cin >> a >> b >> c;
    Largest lrg(a, b, c);
    cout << "Largest number= " << lrg.getLargest() << endl;
}