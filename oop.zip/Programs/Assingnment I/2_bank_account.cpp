#include <iostream>
using namespace std;

class BankAccount
{

    string depositor_name, acc_num, acc_type;
    int acc_bal;

public:
    void createAccount(string name, string acc_num, string acc_type)
    {
        this->depositor_name = name;
        this->acc_num = acc_num;
        this->acc_type = acc_type;
        this->acc_bal = 0;
    }
    void deposit(int amt)
    {
        acc_bal += amt;
    }
    void withdraw(int amount)
    {
        if (amount > acc_bal)
        {
            cout << "Insufficient Balance. Can not withdraw." << endl;
            return;
        }
        acc_bal -= amount;
    }
    void display()
    {
        cout << "Depositor's name : " << depositor_name << endl;
        cout << "Account balance  : " << acc_bal << endl;
    }
};

int main()
{
    BankAccount arbab, haris;
    haris.createAccount("Haris", "FNRB987654321", "Current");
    haris.display();
    haris.deposit(2000);
    haris.display();
    haris.withdraw(2000);
    haris.display();
    haris.withdraw(500);
    haris.display();
}