#include <iostream>
using namespace std;

#define TOTAL_ACC 10

class BankAccount
{

    string depositor_name, acc_type, password;
    int acc_num, acc_bal;
    bool logged_in;

public:
    int user_id;
    bool login(int user_id, string password)
    {
        logged_in = (user_id == this->user_id && password == this->password);
        return logged_in;
    }
    void logout()
    {
        logged_in = false;
    }
    void createAccount(string name, int acc_num, string acc_type, int user_id, string password)
    {
        this->depositor_name = name;
        this->acc_num = acc_num;
        this->acc_type = acc_type;
        this->acc_bal = 0;
        this->user_id = user_id;
        this->password = password;
        this->logged_in = false;
    }
    void deposit(int amt)
    {
        if (!logged_in)
        {
            cout << "Unauthorized access" << endl;
            return;
        }
        acc_bal += amt;
    }
    void withdraw(int amt)
    {
        if (!logged_in)
        {
            cout << "Unauthorized access" << endl;
            return;
        }

        if (amt > acc_bal)
        {
            cout << "Insufficient Balance" << endl;
            return;
        }
        acc_bal -= amt;
    }
    void display()
    {
        if (!logged_in)
        {
            cout << "Unauthorized access" << endl;
            return;
        }

        cout << "Depositor's Name : " << depositor_name << endl;
        cout << "Account Balance  : " << acc_bal << endl;
    }
};

void createAccount(BankAccount accounts[], int current_size, int acc_num)
{
    BankAccount acc;
    string name, acc_type, password;

    cout << "Inpute your name: ";
    cin >> name;
    cout << "Input the account type: ";
    cin >> acc_type;
    cout << "Your user id will be " << acc_num << endl;
    cout << "Input your new password: ";
    cin >> password;

    acc.createAccount(name, acc_num, acc_type, acc_num, password);
    accounts[current_size] = acc;
    cout << "Account created successfully" << endl;
}

// Returns index of correct account else -1
int login(BankAccount accounts[])
{
    int user_id;
    string password;
    int i;

    cout << "Input user id: ";
    cin >> user_id;
    // Searching the account in array of accounts
    for (i = 0; i < TOTAL_ACC; i++)
    {
        if (accounts[i].user_id == user_id)
        {
            break;
        }
    }
    if (i == TOTAL_ACC)
    {
        cout << " -------------------------\n";
        cout << "| !! User id not found !! |\n";
        cout << " -------------------------" << endl;
        return -1;
    }

    // Account is at index i
    cout << "Input password: ";
    cin >> password;
    if (accounts[i].login(user_id, password))
    {
        cout << " ------------------------\n";
        cout << "| Logged in successfully |\n";
        cout << " ------------------------\n"
             << endl;
        return i;
    }
    else
    {
        cout << " ----------------------\n";
        cout << "| !! Wrong password !! |\n";
        cout << " ----------------------\n"
             << endl;
        return -1;
    }
}
int main()
{
    BankAccount accounts[TOTAL_ACC];
    int current_size = 0, acc_num = 100;
    char cmd;
    while (true)
    {
        cout << "===================================\n";
        cout << "Input l to login\n";
        cout << "c to create new account\n";
        cout << "q to quit\n";
        cout << "===================================\n"
             << endl;
        cin >> cmd;
        if (cmd == 'q')
        {
            exit(0);
        }
        else if (cmd == 'c')
        {
            createAccount(accounts, current_size, acc_num);
            current_size++;
            acc_num++;
        }
        else if (cmd == 'l')
        {
            int i = login(accounts);
            if (i != -1)
            {
                cout << "===================================\n";
                cout << "Input s to show the account details.\n";
                cout << "Input d to deposit money.\n";
                cout << "Input w to withdraw money.\n";
                cout << "Input x to logout.\n";
                cout << "===================================\n"
                     << endl;

                while (true)
                {
                    cin >> cmd;
                    if (cmd == 's')
                    {
                        accounts[i].display();
                    }
                    else if (cmd == 'd')
                    {
                        int amt;
                        cout << "Enter amount to be deposited: ";
                        cin >> amt;
                        accounts[i].deposit(amt);
                    }
                    else if (cmd == 'w')
                    {
                        int amt;
                        cout << "Enter amount to be withdrawn: ";
                        cin >> amt;
                        accounts[i].withdraw(amt);
                    }
                    else if (cmd == 'x')
                    {
                        accounts[i].logout();
                        break;
                    }
                    else
                    {
                        cout << "Wrong input" << endl;
                    }
                }
            }
        }
    }
}