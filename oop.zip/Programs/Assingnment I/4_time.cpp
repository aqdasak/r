#include <iostream>
using namespace std;
class Time
{
public:
    int hour, minute;
    void gettime(int h, int m)
    {
        hour = h + m / 60;
        minute = m % 60;
    }
    void input()
    {
        int h, m;
        cout << "Enter Hours : ";
        cin >> h;
        cout << "Enter minutes : ";
        cin >> m;
        gettime(h, m);
    }

    void sum(Time obj)
    {
        gettime(hour + obj.hour, minute + obj.minute);
    }

    void display()
    {
        cout << "Time: " << hour << ":" << minute << endl;
    }
};

int main()
{
    Time t1, t2;

    t1.input();
    t1.display();

    cout << endl;
    t2.input();
    t2.display();

    cout << "\nAdding the times\n";
    t1.sum(t2);
    t1.display();

    return 0;
}