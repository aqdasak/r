#include <iostream>
using namespace std;
class Complex
{
    int real, img;

public:
    Complex()
    {
        real = 0;
        img = 0;
    }
    Complex(int a)
    {
        real = img = a;
    }
    Complex(int a, int b)
    {
        real = a;
        img = b;
    }
    friend Complex add(Complex &, Complex &);
    friend void display(Complex);
};

Complex add(Complex &comp1, Complex &comp2)
{
    Complex result;
    result.real = comp1.real + comp2.real;
    result.img = comp1.img + comp2.img;
    return result;
}

void display(Complex comp)
{
    cout << comp.real;
    if (comp.img >= 0)
    {
        cout << "+";
    }
    cout << comp.img << "i" << endl;
}

int main()
{
    Complex c1(2), c2(3, -4);

    display(c1);
    display(c2);

    cout << "Adding the complex numbers:\n";
    Complex c3 = add(c1, c2);
    display(c3);

    return 0;
}