// 1. Check whether a number is even or odd by overloading ‘!’ operator.

#include <iostream>
using namespace std;

class Number
{
    int num;

public:
    Number()
    {
        num = 0;
    }

    Number(int number)
    {
        num = number;
    }

    void set(int number)
    {
        num = number;
    }

    bool operator!()
    {
        return num % 2 == 0;
    }
};

int main()
{
    int num;
    cout << "Enter a number : ";
    cin >> num;

    Number number(num);

    if (!number)
        cout << "Even Number" << endl;
    else
        cout << "Odd Number" << endl;
    return 0;
}
