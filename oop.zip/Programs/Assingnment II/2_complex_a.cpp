/*
2. Write a Program to add two complex number objects of class Complex having real and imag as data members by overloading ‘+’ operator
    a) Using Member function.
    b) Using Friend Function.
*/

#include <iostream>
using namespace std;
class Complex
{

public:
    int real = 0, imag = 0;
    void display()
    {
        {
            cout << real;
            if (imag >= 0)
            {
                cout << "+";
            }
            cout << imag << "i";
        }
    }

    Complex operator+(Complex &obj)
    {
        Complex cmp;
        cmp.real = this->real + obj.real;
        cmp.imag = this->imag + obj.imag;
        return cmp;
    }
};

Complex inputComplexNum()
{
    Complex comp;
    cout << "Real part     : ";
    cin >> comp.real;
    cout << "Imaginary part: ";
    cin >> comp.imag;
    return comp;
}

int main()
{
    Complex c1, c2, c3;

    cout << "Enter first complex number:\n";
    c1 = inputComplexNum();
    c1.display();

    cout << "\n\nEnter second complex number:\n";
    c2 = inputComplexNum();
    c2.display();

    c3 = c1 + c2;
    cout << "\n\n";
    c1.display();
    cout << " + ";
    c2.display();
    cout << " = ";
    c3.display();
    cout << endl;

    return 0;
}