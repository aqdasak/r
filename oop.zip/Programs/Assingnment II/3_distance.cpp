/* 3. Class Distance consists of length in feet and inches. Class Distance contains
one default constructor
one parameterized constructor
function getdata() to take the value of feet and inches.
function show() to display.
    a) Overload ‘<’ operator to compare the two given distances.
    b) Overload ‘+=’ operator in the Distance class.
*/

#include <iostream>
using namespace std;

class Distance
{
    int feet, inches;

public:
    Distance()
    {
        feet = 0;
        inches = 0;
    }
    Distance(int feet, int inches)
    {
        feet += inches / 12;
        inches = inches % 12;
        this->feet = feet;
        this->inches = inches;
    }
    void getdata()
    {
        cout << "Enter length in feet and inches:" << endl;
        cin >> feet >> inches;
        feet += (inches / 12);
        inches = (inches % 12);
    }
    void show()
    {
        cout << feet << " feet " << inches << " inches" << endl;
    }
    bool operator<(Distance &);
    void operator+=(Distance &);
};
bool Distance::operator<(Distance &ob)
{
    int length = 12 * feet + inches;
    int objLength = 12 * ob.feet + ob.inches;
    return length < objLength;
}
void Distance::operator+=(Distance &ob)
{
    int in = inches + ob.inches;

    feet = feet + ob.feet + (in / 12);
    inches = in % 12;
}
int main()
{
    Distance Length1, Length2, Length3;
    Length1.getdata();
    Length2.getdata();
    Length3.getdata();

    cout << "Length 1 : ";
    Length1.show();
    cout << "Length 2 : ";
    Length2.show();
    cout << "Length 3 : ";
    Length3.show();

    Length1 += Length2;
    cout << "\nLength 1 += Length 2\nLenght 1: ";
    Length1.show();

    cout << "\nLength 3 < Length 2 : " << (Length3 < Length2 ? "true" : "false") << endl;
}