/*
4. Concatenate two string objects of a class String having char str[] and len as data members by overloading ‘+’ operator. Also overload ‘==’, ‘>’ and ‘<’ operators to compare two given String objects.
*/

#include <iostream>
#include <cstring>
using namespace std;

class String
{

private:
    char *str;
    int len;

public:
    String(const char *str)
    {
        len = strlen(str);
        this->str = new char[len + 1];
        strcpy(this->str, str);
    }
    String(String &other)
    {
        len = other.len;
        str = new char[len + 1];
        strcpy(str, other.str);
    }
    String operator+(String &other)
    {
        char *newStr = new char[len + other.len + 1];
        strcpy(newStr, str);
        strcat(newStr, other.str);
        return String(newStr);
    }
    bool operator==(String &other)
    {
        return strcmp(str, other.str) == 0;
    }
    bool operator>(String &other)
    {
        return strcmp(str, other.str) > 0;
    }
    bool operator<(String &other)
    {
        return strcmp(str, other.str) < 0;
    }
    void display()
    {
        cout << str;
    }
};

void compare(String s1, String s2, string op, int result)
{
    cout << "\"";
    s1.display();
    cout << "\" " << op << " \"";
    s2.display();
    cout << "\"";
    cout << ": " << (result ? "true" : "false") << endl;
}
int main()
{
    String s1("Hello");
    String s2("World");

    String s3 = s1 + s2;
    s3.display();
    cout << endl;

    compare(s1, s2, "==", s1 == s2);
    compare(s1, s2, "<", s1 < s2);
    compare(s1, s2, ">", s1 > s2);

    return 0;
}
