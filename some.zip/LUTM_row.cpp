#include<iostream>
using namespace std;
void read(int *a, int n){
  cout<<"Enter the non-null element of Left Upper Triangular Matrix in row major order\n";
  for(int i=0; i<n*(n+1)/2; i++)
    cin>>a[i];
}
void print(int *a, int n){
  cout<<"The Matrix\n";
  for(int i=0; i<n; i++){
    for(int j=0; j<n; j++)
      if(i+j<n)
        cout<<a[(n*i)-((i*(i-1))/2)+j]<<"\t";
      else
        cout << "0\t";
    cout<<"\n";
  }
}
int main()
{
  int n;
  cout<<"\nEnter n ";
  cin>>n;
  int *a= new int[n*(n+1)/2];
  read(a, n);
  print(a, n);
  return 0;
}


