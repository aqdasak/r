#include<iostream>
using namespace std;
void read(int *a, int n){
  cout<<"Enter the non-null element of Upper Triangular Matrix in row major order\n";
  for(int i=0; i<n*(n+1)/2; i++)
    cin>>a[i];
}
void print(int *a, int n){
  cout<<"The Matrix\n";
  for(int i=0; i<n; i++){
    for(int j=0; j<n; j++)
      if(i<=j)
        cout<<a[(n*i)-(i*(i-1)/2)+(j-i)]<<"\t";
      else
        cout << "0\t";
    cout<<"\n";
  }
}
int *multiplyUTM(int *a, int *b, int n){
    int *c = new int[n*(n+1)/2];
    for(int i = 0; i < n; i++ )
        for(int j = i; j < n; j++)
            for(int k = i; k <= j; k++)
                c[(n*i)-(i*(i-1)/2)+(j-i)]=c[(n*i)-(i*(i-1)/2)+(j-i)]+(a[(n*i)-(i*(i-1)/2)+(k-i)]*b[(n*k)-(k*(k-1)/2)+(j-i)]);
    return c;
}
int main()
{
  int n;
  cout<<"\nEnter n ";
  cin>>n;
  int *a= new int[n*(n+1)/2];
  read(a, n);
  print(a, n);
  int *b= new int[n*(n+1)/2];
  read(b, n);
  print(b, n);
  int *c= new int[n*(n+1)/2];
  c = multiplyUTM(a,b,n);
  print(c,n);
  return 0;
}


